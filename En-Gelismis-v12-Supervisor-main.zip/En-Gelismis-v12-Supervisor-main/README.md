# En-Gelismis-v12-Supervisor
quick.db li En Büyük Public Ve Ekipler İçin Yapılmış Olan Süpervisor 100 den fazla komuta sahiptir
