const Discord = require('discord.js');//KΞJ ツ XRD-EnDeRmAn#0666

module.exports = {
    name: "nitrover",
    aliases: ["nitrover"],
    execute: async (client, message, args, embed, author, channel, guild) => {

message.channel.send("**Aga Dm den Yolladım H.o :D**")
message.author.send("https://cdn.discordapp.com/attachments/798433248773800016/798832466906316800/SPOILER_freenitro.mp4")//KΞJ ツ XRD-EnDeRmAn#0666

}}